package com.Bits.ibits;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



import java.text.DecimalFormat;




public class MainActivity extends Activity implements View.OnClickListener {

    DecimalFormat precision = new DecimalFormat("0.00");
    private Button b,c,d;
    Button btn;

    Float Factor = 0.014f;
    Integer amount = null;








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);










        final TextView tv1, tv2, tv3, tv4, tv5, tv6, tv7, tv8;


        tv1 = (TextView) findViewById(R.id.textView9);
        tv2 = (TextView) findViewById(R.id.textView10);
        tv3 = (TextView) findViewById(R.id.textView11);
        tv4 = (TextView) findViewById(R.id.textView12);
        tv5 = (TextView) findViewById(R.id.textView13);
        tv6 = (TextView) findViewById(R.id.textView14);
        tv7 = (TextView) findViewById(R.id.textView16);
        tv8 = (TextView) findViewById(R.id.textView18);

        final EditText et = (EditText) findViewById(R.id.editText);


        Button button = (Button) findViewById(R.id.button);


        tv1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //TODO Auto-generated method stub
                amount= 0;
            }
        });
        tv2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                amount= 1;
            }
        });
        tv3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                amount = 2;
            }
        });
        tv4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                amount = 3;
            }
        });
        tv5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                amount = 4;
            }
        });
        tv6.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                amount = 5;
            }
        });

        tv7.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                amount = 6;
            }
        });
        tv8.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //TODO Auto-generated method stub
                amount= 7;
            }
        });
        button.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        Integer amount;

                        try
                        {
                            amount = Integer.parseInt(et.getText().toString());




                        } catch (Exception e) {
                            et.setText(null);
                            Toast.makeText(MainActivity.this, "Enter Bits", Toast.LENGTH_SHORT).show();

                            return;
                        }
                if (et.getText().toString().equals("")) {



                    Toast.makeText(MainActivity.this, "Please Enter value.", Toast.LENGTH_SHORT).show();
                } else{

                    //buy
                    tv1.setText( precision.format(amount*Factor));
                    //Tip dollars
                    tv2.setText( precision.format(amount * 0.01));
                    //Fee
                    tv6.setText( precision.format((amount * Factor)-(amount * 0.01)));
                    //Tip Euros
                    tv3.setText( precision.format(amount * (0.93 * 0.01)));
                    //Tip Mexican Pesos
                    tv4.setText( precision.format(amount * (25.15 * 0.01)));
                    //Tip Real Brasileiro
                    tv5.setText( precision.format(amount * (5.14 * 0.01)));
                    //Tip Rublo ruso
                    tv7.setText( precision.format(amount * (79.76 * 0.01)));
                    //Tip Peso Argentino
                    tv8.setText( precision.format(amount * (63.69 * 0.01)));





                }



                Toast.makeText(MainActivity.this, "AT BUY (Discount not included).", Toast.LENGTH_SHORT).show();










           /*editText.setText(String.valueOf(Math.round(bits)));
           editText.setText("");
           *
           *
           * */


            }








        });




        /*JUMP CALCULATOR ACTIVITY*/
        b = findViewById(R.id.button2);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent_one = new Intent(MainActivity.this, Calc_Main2.class);
                startActivity(intent_one);
            }
        });

        /*JUMP F list*/
    c = findViewById(R.id.button3);
        c.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent_two = new Intent(MainActivity.this, F.class);
            startActivity(intent_two);
        }
    });


}





    @Override
    public void onClick(View view) {


    }
}


